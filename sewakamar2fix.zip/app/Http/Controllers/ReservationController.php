<?php

namespace App\Http\Controllers;

use App\Room;
use App\User;
use App\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use DB;
use Auth;

class ReservationController extends Controller
{

    public function search(Request $request)
    {
      // $room = DB::table('rooms')
      //       ->join('reservations', 'rooms.id', '=', 'reservations.room_id')
      //       ->select('rooms.*')
      //       ->Where('rooms.city', 'LIKE', '%' . $request->city . '%')
      //       ->Where('rooms.status', '=', 1)
      //       ->orwhereNotIn('reservations.start_date', [$request->start_date, $request->end_date])
      //       ->orWhereNotBetween('reservations.start_date', array($request->start_date, $request->end_date))
      //       ->orWhereNotBetween('reservations.end_date', array($request->start_date, $request->end_date))
      //       ->get();
      // $room = DB::table('rooms')
      //         ->whereNotIn('room_id', function($query)
      //          {
      //             $query->select('room_id')
      //                 ->from(with(new Reservation)->getTable())
      //                 ->where(function($query)
      //                 {
      //                     $query->where('start_date', '<', $reservation->room->end_date)
      //                         ->orWhere('end_date', '>', $reservation->room->start_date);
      //                 });
      //          })
      //         ->orderBy('room_id')
      //         ->get();
      // dd($request->query)
//       dd($request->start_date);
//
//       $room = DB::select("
//       select * from rooms where id not in
// (select rooms.id from rooms left outer join reservations on reservations.room_id = rooms.id
// where $request->start_date between reservations.start_date AND reservations.end_date)
// and city  like 'depok' and person <= 2 order by rooms.updated_at asc;
//       ");

      $this->validate($request, [
        'person' => 'required',
        'start_date' => 'required',
        'end_date' => 'required'
      ]);

      $room = DB::select('
                            SELECT
                      *
                      FROM
                      rooms
                      WHERE
                      id NOT IN (
                           SELECT
                               rooms.id
                           FROM
                               rooms
                           LEFT OUTER JOIN
                               reservations ON reservations.room_id = rooms.id
                           WHERE
                          :start_date BETWEEN reservations.start_date AND reservations.end_date
                          AND
                          :end_date BETWEEN reservations.start_date AND reservations.end_date
                         )
                      AND
                      city LIKE :city
                      AND
                      person >= :person
                      ORDER BY
                      rooms.updated_at
                      asc',
                       ['start_date' => $request->start_date,
                       'end_date' => $request->end_date,
                       'city' => "%$request->city%",
                       'person' => $request->person
                     ]
      );

      $allroom = DB::select('
              SELECT * FROM rooms
      ');
      // dd($room);
      // dd(request()->fullUrlWithQuery(["sort"=>"desc"]));
      // dd($request->query());
      $qs = $request->fullUrl();
      $qs = explode('?', $qs);
      $qs = $qs[1];

      return view('room.search', ['room' => $room, 'qs' => $qs, 'allroom' => $allroom]);
    }

    public function RoomSearch(Request $request, $id, $city, $start_date, $end_date, $person)
    {
      // $data = array(
      //   'city' => $request->city,
      //   'start_date' => $request->start_date,
      //   'end_date' => $request->end_date,
      //   'person' => $request->person,
      // );
      return view('room.show');
    }

    public function show($id)
    {
      // $room = DB::select('
      //                       SELECT
      //                 *
      //                 FROM
      //                 rooms
      //                 WHERE
      //                 id IN (
      //                     SELECT
      //                       rooms.id
      //                     FROM
      //                       rooms
      //                     LEFT OUTER JOIN
      //                       reservations ON reservations.room_id = rooms.id
      //                     WHERE
      //                       reservations.user_id = :id
      //                   )',
      //                   [
      //                     'id' => $id
      //                   ]
      //
      // );
      // var tsb menampilkan semua room yg direservasi user_id

      // dd($room);
      $user = User::findOrFail($id);

      // $room = DB::select("
      //   SELECT * FROM users
      //   WHERE id IN (
      //           SELECT users.id FROM users
      //           LEFT OUTER JOIN
      //           rooms ON rooms.user_id = users.id
      //           WHERE
      //           rooms.user_id IN (
      //             SELECT user_id FROM rooms
      //             )
      //     )
      //
      // ");
      // $room = Room::find(2);
      // dd($user->rooms->pivot->user);
      $reservations = Reservation::whereHas('room', function ($query) use($id) {
      $query->where('user_id', '=', $id);
      })->get();

      // dd($reservation);

      // $rooms = Room::whereHas;

      // menampilkan semua dari room dimana id nya didalam table reservasi
      // $room = Room::find(4);
      // dd($room->reservations);

      return view('reservation.show', [
        'reservations' => $reservations,
        'user' => $user
        // 'room' => $room
      ]);
    }

    public function confirmation($id, Request $request)
    {
      // $user = User::find($id);
      // $reservations = Reservation::whereHas('room', function ($query) use($id) {
      // $query->where('user_id', '=', $id);
      // })->get();

                // akhirnya ini berhasilll gannnnn yeaayyyyyyyyy
                foreach ($request->status as $key => $data ) {

                       $input = [
                           'status' => $data,
                       ];
                       DB::table('reservations')->where('id',$key)->update($input);
                }

                // $a = $request->input('status');
                // dd($a);
                //
                // dd($request->status[$reservation->id]);
                // dd(DB::table('reservations')->where('id', $request->status));
                // foreach ($reservations as $row) {
                //     $desired_keys = ([
                //         'status'
                //     ]);
                //     $input = array($row, $desired_keys);
                //     DB::table('reservations')->where('id', $row['id'])->update($input);
                // }

      // dd($request);
      // $reservations->update([
      //   $request->all()
      // ])->save();

      // if ($request->has('status')) {
      //   Reservation::query()->update(array('status' => $request->status));
      // }
      // foreach ($reservations as $reservation) {
      //   if ($request->has('status')) {
      //     $reservation->query()->update(['status' => $request->status]);
      //   }
      // }

      // $status = Input::get('status');

      // foreach ($status as $key => $value) {
      //   $reservation = Reservation::find( $status[$key] );
      //
      //   $arrData[] = array(
      //     'status' => $status[$key]
      //   );
      //
      //   $reservation->save();
      // }
      // $reservations->query()->save($arrData);

      // dd($reservations->status);
      // $reservations->status->update([
      //   'status' => $request->status
      // ]);

      return redirect('user/' . Auth::user()->id . '/reservation');
    }

}
