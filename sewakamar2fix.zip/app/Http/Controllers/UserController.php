<?php

namespace App\Http\Controllers;

use App\User;
use App\Models\Profile;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function show($id)
    {
      return view('user.profile', ['user' => User::findOrFail($id)]);


      //jika image kosong bisa default
    //   $file = $user->image;
    //
    //   if ( empty($file) ) {
    //     // No file exists.
    //     return asset('empty_profile.png');
    // }

      // return view('user.profile', ['profile' => Profile::findOrFail($id)]);
    }

    public function edit($id, User $user)
    {
      $user = User::findOrFail($id);

      return view('user/edit' , ['user' => $user]);
    }

    public function update(Request $request, $id)
    {
      $this->validate($request, [
        'image' => 'mimes:jpeg,jpg,png|max:2000'
      ]);

      $user = User::findOrFail($id);

      if ($request->hasFile('image')) {

        $imageName = time().'.'.$request->image->getClientOriginalName().'.'.$request->image->getClientOriginalExtension();
        $request->file('image')->storeAs('public/user', $imageName);

        $user->update([
          'image' => $imageName
        ]);


        // if ($user->image === null) {
        //   $user->image->update($imageName);
        // }

      }

      $user->update([
          'name'      => $request->name,
          'fullname'  => $request->fullname,
          'phone'     => $request->phone,
          'city'      => $request->city,
          'birth'     => $request->birth
      ]);


      // $user->update([
      //     'name'      => $request->name,
      //     'fullname'  => $request->fullname,
      //     'phone'     => $request->phone,
      //     'city'      => $request->city,
      //     'birth'     => $request->birth,
      // ]);
      //   $user->save($request);
          return view('user.profile', ['user' => User::findOrFail($id)]);
      }




// Ini Work tapi mass asignment
      // $user = User::with('profile')->findOrFail($id);
      // if ($user->profile === null)
      // {
      //     $profile = new Profile([
      //                   'name' => 'test'
      //                 ]);
      //     $user->profiles()->save($profile);
      // }
      // else
      // {
      //     $user->profile->update(['name' => 'testt']);
      // }





      //     // Get current profile
      //  $profile = $user->profile;
      //
      //  // Create a new profile if one already doesn't exist
      // //  if (! count($profile)) {
      // //      $profile = new Profile;
      // //      $profile->user_id = $user->id;
      // //  }
      //
      // // Update profile data
      // $profile->name = $request->name;
      // $profile->phone = $request->phone;
      // $profile->city = $request->city;
      // $profile->birth = $request->birth;
      // $profile->image = $request->image;
      //
      // //  $profile->foo = $request->input('foo');
      // //  $profile->bar = $request->input('bar');
      //
      //
      // // Save changes to database
      // $user->profiles()->save($profile);
      // //  $profile->save();
      //
      //  // Return a response
      //  return view('user.profile');

      // $profile = Profile::find($id);
      // $profile = $user->profile;
      // // $profile->user_id = $request->Auth::user()->id;
      // $profile->name = $request->name;
      // $profile->phone = $request->phone;
      // $profile->city = $request->city;
      // $profile->birth = $request->birth;
      // $profile->image = $request->image;
      // $user->profiles()->save($profile);


    // public function showProfile($id)
    // {
    //   return view('user.profile', ['profile' => Profile::findOrFail($id)]);
    // }

    // public function editProfile($id)
    // {
    //   $user = User::find($id);
    //
    //   return view('user/edit', ['user' => $user]);
    // }
    //
    // public function storeProfile(Request $request)
    // {
    //   $profile = new Profile;
    //   $profile->$name = $request->$name;
    //   $profile->$phone = $request->$phone;
    //   $profile->$city = $request->$city;
    //   $profile->$birth = $request->$birth;
    //   $profile->$image = $request->$image;
    //   $profile->save();
    //
    //   return redirect('/user');
    //
    //
    // }

}
