@extends('layouts.master')

@section('title')
  Tes Home
@endsection

@section('content')

  <p>tes ini content</p>


@endsection
