<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <form class="form-group-sm" action="/user/<?php echo e(Auth::user()->id); ?>" method="post">
      <input type="text" name="name">
      <input type="text" name="phone">
      <input type="text" name="city">
      <input type="date" name="birth">
      <input type="file" name="image">
      <input type="submit" name="submit" value="create">
      <?php echo e(csrf_field()); ?>


    </form>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>