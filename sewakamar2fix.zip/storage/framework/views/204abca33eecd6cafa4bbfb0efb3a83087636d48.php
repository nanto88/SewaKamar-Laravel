<?php $__env->startSection('title'); ?>
    Konfirmasi Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <h3>Confirmation Check-in & Check-out</h3>
    <?php if(strpos($url, '?') == false): ?>

      <form action="booking" method="post">
        <div class="form-group">
          <label for="name">Check In</label>
          <input class="form-control" type="text" name="start" readonly>
        </div>
        <div class="form-group">
          <label for="name">Check Out</label>
          <input class="form-control" type="text" name="end" readonly>
        </div>
        <input type="hidden" name="room_id" value="<?php echo e($request->room_id); ?>">

        <div class="alert alert-info">
          check-in dan check-out harus mengisi pada saat search di halaman home
        </div>
        <a href="/home">
        <button class="btn btn-default" type="button" name="button">Back To Search</button>
        </a>

        <?php echo e(csrf_field()); ?>


      </form>

    <?php else: ?>

      <form action="booking" method="post">
        <div class="form-group">
          <label for="name">Check In</label>
          <input class="form-control" type="text" name="start" value="<?php echo e($request->start_date); ?>" readonly>
        </div>
        <div class="form-group">
          <label for="name">Check Out</label>
          <input class="form-control" type="text" name="end" value="<?php echo e($request->end_date); ?>" readonly>
        </div>
        <input type="hidden" name="room_id" value="<?php echo e($request->room_id); ?>">

        <input class="btn btn-default" type="submit" name="submit" value="Continue">
        <a href="/home">
        <button class="btn btn-default" type="button" name="button">Back To Search</button>
        </a>

        <?php echo e(csrf_field()); ?>


      </form>

    <?php endif; ?>

  </div>
  <br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>