<div class="col col-xs-2">
  <ul class="nav nav-pills nav-stacked">
    <li class="well-sm"><a href="/user/<?php echo e(Auth::user()->id); ?>/edit">Edit Profile</a></li>
    <li class="well-sm"><a href="<?php echo e(Auth::user()->id); ?>/booking">Cek Reservasi</a></li>

  </ul>
</div>
