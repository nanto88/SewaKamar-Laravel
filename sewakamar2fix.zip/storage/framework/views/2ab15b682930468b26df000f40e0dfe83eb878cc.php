<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col col-xs-2">
        <ul>
          <li><a href="/users/<?php echo e(Auth::user()->id); ?>/edit">Edit Profile</a></li>
          <li><a href="/users/<?php echo e(Auth::user()->id); ?>/rooms">Daftar Properti</a></li>

        </ul>
      </div>

      <div class="col col-xs-10">
        <a href="/users/<?php echo e(Auth::user()->id); ?>/rooms/create" class="btn btn-success">
          <span class="glyphicon glyphicon-plus"></span> Tambah Properti</a>

        <div class="panel panel-default">
        <!-- Default panel contents -->
          <div class="panel-heading"><h3>Daftar Properti</h3></div>
          <div class="panel-body">

<?php if($user->rooms()->count() === null): ?>

        <p>No Data Available</p>


<?php else: ?>
        <div class="row">
        <?php $__currentLoopData = $user->rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col col-xs-6 col-md-4">
            <div class="thumbnail">
              <a href="users/<?php echo e(Auth::user()->id); ?>/rooms/<?php echo e($room->id); ?>">
                <img src="<?php echo e(asset('storage/room/' . $room->image)); ?>" alt="room image" style="height: 180px">
                <div class="caption">
                  <h3><?php echo e($room->name); ?></h3>
                  </a>
                  <p><?php echo e($room->description); ?></p>
                  <p><?php echo e($room->price); ?></p>
                  <p><?php echo e($room->city); ?></p>
                  <p><?php echo e($room->location); ?></p>
                  <a href="rooms/<?php echo e($room->id); ?>/edit">
                    <span class="glyphicon glyphicon-cog"></span>
                    Update Properti
                  </a>
                  <a href="users/<?php echo e(Auth::user()->id); ?>/rooms/<?php echo e($room->id); ?>">
                    <span class="glyphicon glyphicon-cog"></span>
                    Delete Properti
                  </a>
                </div>

            </div>

          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<?php endif; ?>

            
            </div>
          </div>


        </div>
      
      </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>