<?php $__env->startSection('title'); ?>
    Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col col-xs-2">
      <ul class="nav nav-pills nav-stacked">
        <li class="well-sm"><a href="/user/<?php echo e(Auth::user()->id); ?>">Profile</a></li>
        <li class="well-sm"><a href="booking">Cek Booking</a></li>
        <li class="well-sm"><a href="reservation">Cek Pesanan</a></li>

      </ul>
    </div>

    <div class="col col-xs-10">
      <img src="<?php echo e(asset('storage/user/' . $user->image)); ?>" alt="" width="150">
      <h1>Halo <?php echo e($user->name); ?></h1>

      <div class="panel panel-default">
      <!-- Default panel contents -->
        <div class="panel-heading"><h3>Daftar Booking</h3></div>
        <div class="panel-body">

    <?php if($user->reservations()->count() == null): ?>

          <p>No Data Available</p>


        </div>
      </div>



    <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Check-in</th>
                <th>Check-out</th>
                <th>Room</th>
                <th>Price</th>
                <th>Total</th>
                <th>Owner</th>
                <th>Contact</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              

            <?php $__currentLoopData = $user->reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td> <?php echo e($reservation->start_date); ?> </td>
                  <td> <?php echo e($reservation->end_date); ?> </td>
                  <td>
                    <a href="/room/<?php echo e($reservation->room_id); ?>">
                      Room <?php echo e($reservation->room->name); ?>

                    </a>
                  </td>
                  <td> Rp. <?php echo e($reservation->room->price); ?> </td>
                  <td>
                    <?php
                      $start     = date_create($reservation->start_date);
                      $end       = date_create($reservation->end_date);
                      $interval  = $start->diff($end)->format('%a');
                      $total    = ($interval * $reservation->room->price);
                     ?>
                    Rp. <?php echo e($total); ?>

                  </td>
                  <td>
                    
                    <?php if( $reservation->room->user->fullname == null ): ?>
                        <?php echo e($reservation->room->user->name); ?>

                    <?php else: ?>
                        <?php echo e($reservation->room->user->fullname); ?>

                    <?php endif; ?>
                  </td>
                  <td> <?php echo e($reservation->room->user->phone); ?> </td>
                  <td>
                    <?php if($reservation->status == 0): ?>
                      <span class="glyphicon glyphicon-hourglass"></span>
                      Menunggu Konfirmasi
                    <?php elseif($reservation->status == 1): ?>
                      <span class="glyphicon glyphicon-ok"></span>
                      Diterima
                    <?php elseif($reservation->status == 2): ?>
                      <span class="glyphicon glyphicon-remove"></span>
                      Tidak Diterima
                    <?php endif; ?>
                  </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
          </table>
          <div class="panel panel-footer">
              Segera kontak owner jika booking diterima
          </div>
        </div>


      </div>

    </div>

    <?php endif; ?>

          


    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>