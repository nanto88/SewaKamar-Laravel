<?php $__env->startSection('title'); ?>
    Room
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col col-xs-6">
        <div class="thumbnail">
            <img src="<?php echo e(asset('storage/room/' . $room->image)); ?>" alt="room image" style="height: 380px">
        </div>
      </div>

      <div class="col col-xs-4">
          <div class="text-left">
            <div class="well">
                <h2 class="title"><?php echo e($room->name); ?></h2>
                <p><?php echo e($room->description); ?></p>
                <p><?php if($room->category_id == 1): ?>
                  Bedroom
                <?php elseif($room->category_id == 2): ?>
                  Hotel
                <?php else: ?>
                  Gazebo
                <?php endif; ?></p>
                <p>Rp. <?php echo e($room->price); ?></p>
                <p>Max Person: <?php echo e($room->person); ?></p>
                <p><span class="glyphicon glyphicon-map-marker"></span> <?php echo e($room->city); ?> ,
                <br> <?php echo e($room->location); ?></p>
                <hr>
                <h3>Kontak</h3>
                <p><?php echo e($room->user->fullname); ?></p>
                <p><span class="glyphicon glyphicon-phone"></span> <?php echo e($room->user->phone); ?></p>
                

                
                <?php if(count('?') > 1): ?>
                  <a href="/booking?<?php echo e($qs); ?>&room_id=<?php echo e($room->id); ?>">
                  <button class="btn btn-default" type="submit" name="submit">
                      <span class="glyphicon glyphicon-home"></span>
                      Booking
                  </button>
                  </a>
                <?php elseif($room->user->id === Auth::user()->id): ?>
                  <a href="<?php echo e($room->id); ?>/edit">
                  <button class="btn btn-default" type="submit" name="submit">
                      <span class="glyphicon glyphicon-home"></span>
                      Update
                  </button>
                  </a>
                <?php else: ?>
                  <a href="/booking?room_id=<?php echo e($room->id); ?>">
                  <button class="btn btn-default" type="submit" name="submit">
                      <span class="glyphicon glyphicon-home"></span>
                      Booking
                  </button>
                  </a>
                <?php endif; ?>



          </div>
        </div>
      </div>

      <div class="col col-xs-2">
        <h5 class="title">Pemilik</h5>
        <h6><span class="glyphicon glyphicon-user"></span> <?php echo e($room->user->name); ?></h6>
        <hr>
        <h5>Status</h5>
        <h6><?php if($room->status == 1): ?>
          <span class="glyphicon glyphicon-ok"></span> Tersedia
          <?php else: ?>
          <span class="glyphicon glyphicon-remove"></span> Booked
        <?php endif; ?></h6>
      </div>

    </div>
  </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>