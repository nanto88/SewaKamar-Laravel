<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" type="text/css">
    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/customstyle.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('css/datepicker.css')); ?>" type="text/css">
  </head>
  <body>
    <!-- <img src="images/bg.jpg" alt="landing" class="imglanding"> -->
    <!-- percobaan image landing -->
    

    <nav class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/home">SewaKamar</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar">
          <ul class="nav navbar-nav">
            <li><a href="/home"><span class="glyphicon glyphicon-home"></span> Daftarkan Kamar Anda</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <?php if(Auth::guest()): ?>
                <li><a href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                <li><a href="<?php echo e(route('register')); ?>"><span class="glyphicon glyphicon-user"></span> Register</a></li>
            <?php else: ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                        <img src="<?php echo e(asset('/storage/user/' . Auth::user()->image )); ?>" alt="image" class="img-circle" style="height:25px; width:25px">
                         <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <ul class="dropdown-menu" role="menu">
                        <li>
                          <a href="/user/<?php echo e(Auth::user()->id); ?>">Profile</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                                Logout
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>

                    </ul>
                </li>
            <?php endif; ?>

          </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>

      <?php echo $__env->yieldContent('content'); ?>

    <div class="footer">
      <div class="container">
        <p> &copy; Sewa Kamar 2017 </p>
      </div>
    </div>




    <script src="<?php echo e(asset('js/jquery-3.2.1.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>


    
    <script src="<?php echo e(asset('js/moment.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            var start_date_input=$('input[name="start_date"]'); //date input
            var end_date_input=$('input[name="end_date"]'); //date input
            var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
            start_date_input.datepicker({
                format: 'yyyy-mm-dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
                })
            end_date_input.datepicker({
                format: 'yyyy-mm-dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
                })

              })
    </script>
    </script>
    </body>
    </html>
