<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <form action="/user/<?php echo e(Auth::user()->id); ?>" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="username">Username :</label>
        <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>">
        <?php if($errors->has('name')): ?>
          <div class="text-danger">
            <p> <?php echo e($errors->first('name')); ?> </p>
          </div>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Fullname">Fullname :</label>
        <input class="form-control" type="text" name="fullname" value="<?php echo e($user->fullname); ?>">
        <?php if($errors->has('fullname')): ?>
          <div class="text-danger">
            <p> <?php echo e($errors->first('fullname')); ?> </p>
          </div>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Phone">Phone :</label>
        <input class="form-control" type="text" name="phone" value="<?php echo e($user->phone); ?>">
        <?php if($errors->has('phone')): ?>
          <div class="text-danger">
            <p> <?php echo e($errors->first('phone')); ?> </p>
          </div>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="City">City :</label>
        <input class="form-control" type="text" name="city" value="<?php echo e($user->city); ?>">
        <?php if($errors->has('city')): ?>
          <div class="text-danger">
            <p> <?php echo e($errors->first('city')); ?> </p>
          </div>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Birth">Birth :</label>
        <input class="form-control" type="date" name="birth" value="<?php echo e($user->birth); ?>">
        <?php if($errors->has('birth')): ?>
          <div class="text-danger">
            <p> <?php echo e($errors->first('birth')); ?> </p>
          </div>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Upload Image">Upload Image :</label>
        <input class="form-control" type="file" name="image" value="<?php echo e($user->image); ?>">
        <p class="help-block">File harus .jpg,.jpeg,.png dan maksimal 2mb</p>
        <?php if($errors->has('image')): ?>
          <div class="text-danger">
            <p> <?php echo e($errors->first('image')); ?> </p>
          </div>
        <?php endif; ?>
      </div>
      <input class="btn btn-default" type="submit" name="submit" value="Save">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="put">

    </form>
  </div>
  <br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>