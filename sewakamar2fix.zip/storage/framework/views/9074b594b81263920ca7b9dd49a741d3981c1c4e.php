<?php $__env->startSection('title'); ?>
    Update Properti
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <form action="/room/<?php echo e($room->id); ?>" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="name">Room</label>
        <input class="form-control" type="text" name="name" value="<?php echo e($room->name); ?>">
        <?php if($errors->has('name')): ?>
          <p> <?php echo e($errors->first('name')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Description">Description</label>
        <input class="form-control" type="textarea" name="description" value="<?php echo e($room->description); ?>">
        <?php if($errors->has('description')): ?>
          <p> <?php echo e($errors->first('description')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Price">Price</label>
        <input class="form-control" type="number" name="price" value="<?php echo e($room->price); ?>">
        <?php if($errors->has('price')): ?>
          <p> <?php echo e($errors->first('price')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Price">Max Person</label>
        <select class="form-control" name="person">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
        </select>
        <?php if($errors->has('person')): ?>
          <p> <?php echo e($errors->first('person')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Price">Status</label>
        <select class="form-control" name="status">
          <option value="1">Room is ready</option>
          <option value="0">Room is not ready</option>
        </select>
        <?php if($errors->has('status')): ?>
          <p> <?php echo e($errors->first('status')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="City">City</label>
        <input class="form-control" type="text" name="city" value="<?php echo e($room->city); ?>">
        <?php if($errors->has('city')): ?>
          <p> <?php echo e($errors->first('city')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Location">Location</label>
        <input class="form-control" type="text" name="location" value="<?php echo e($room->location); ?>">
        <?php if($errors->has('location')): ?>
          <p> <?php echo e($errors->first('location')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Category">Category</label>
        <select class="form-control" name="category_id">
          <option value="1">Bedroom</option>
          <option value="2">Hotel</option>
          <option value="3">Gazebo</option>
        </select>
        <?php if($errors->has('category')): ?>
          <p> <?php echo e($errors->first('category')); ?> </p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="Upload Image">Upload Image</label>
        <br>
        <img src="<?php echo e(asset('storage/room/' . $room->image )); ?>" alt="room image" style="height: 180px" class="thumbnail">
        <input class="form-control" type="file" name="image">
        <p class="help-block">File harus .jpg,.jpeg,.png dan maksimal 2mb</p>
        
      </div>
      <input class="btn btn-default" type="submit" name="submit" value="Edit">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="put">

    </form>
  </div>
  <br>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>