<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col col-xs-2">
      <ul class="nav nav-pills nav-stacked">
        <li class="well-sm"><a href="/user/<?php echo e(Auth::user()->id); ?>/edit">Edit Profile</a></li>
        <li class="well-sm"><a href="<?php echo e(Auth::user()->id); ?>/reservation">Cek Reservasi</a></li>

      </ul>
    </div>

    <div class="col col-xs-10">
      <img src="<?php echo e(asset('storage/user/' . $user->image)); ?>" alt="" width="150">
      <h1>Halo <?php echo e($user->name); ?></h1>

      <div class="panel panel-default">
      <!-- Default panel contents -->
        <div class="panel-heading"><h3>Daftar Reservasi</h3></div>
        <div class="panel-body">

    <?php if($user->reservations()->count() === null): ?>

          <p>No Data Available</p>


        </div>
      </div>



    <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Check-in</th>
                <th>Check-out</th>
                <th>Room</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              

            <?php $__currentLoopData = $user->reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td> <?php echo e($reservation->start_date); ?> </td>
                  <td> <?php echo e($reservation->end_date); ?> </td>
                  <td>
                    <a href="/room/<?php echo e($reservation->room_id); ?>">
                      Room <?php echo e($reservation->room->name); ?>

                    </a>
                  </td>
                  <td><?php echo e($reservation->room->price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>


      </div>

    </div>

    <?php endif; ?>

          


    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>