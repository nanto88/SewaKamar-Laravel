<?php $__env->startSection('title'); ?>
    Pencarian
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <?php if($room == null): ?>
        <div class="alert alert-info">
          <p><strong>Whoops..</strong> No Rooms Available</p>
        </div>
      <?php endif; ?>
        <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col col-xs-3 col-md-3">

            <div class="thumbnail" >
                <img class="img-thumbnail" src="<?php echo e(asset('storage/room/' . $rooms->image)); ?>" style="max-height: 150px" alt="Card image cap">
              <div class="well">

                <a href="/room/<?php echo e($rooms->id); ?>?<?php echo e($qs); ?>">
                  <h4><?php echo e($rooms->name); ?></h4>
                </a>


                  


                <p class="text-info"><?php echo e($rooms->description); ?></p>
                <p class="text-info">Rp. <?php echo e($rooms->price); ?></p>
                <p class=""><small class="text-muted"><span class="glyphicon glyphicon-map-marker"></span> <?php echo e($rooms->city); ?> ,
                <br> <?php echo e($rooms->location); ?></small></p>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>