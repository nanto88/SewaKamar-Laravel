<?php $__env->startSection('title'); ?>
    Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php if(count('?') === null): ?>

      <form action="booking/payment" method="post">
        <div class="form-group date" data-provide="datepicker">
          <label for="name">Check In</label>
          <input class="form-control" type="text" name="start_date">
          <?php if($errors->has('start_date')): ?>
            <p> <?php echo e($errors->first('start_date')); ?> </p>
          <?php endif; ?>
        </div>
        <div class="form-group date" data-provide="datepicker">
          <label for="name">Check Out</label>
          <input class="form-control" type="text" name="end_date">
          <?php if($errors->has('start_date')): ?>
            <p> <?php echo e($errors->first('start_date')); ?> </p>
          <?php endif; ?>
        </div>
        <input type="hidden" name="room_id" value="<?php echo e($request->room_id); ?>">

        <input class="btn btn-default" type="submit" name="submit" value="Continue Payment">
        <?php echo e(csrf_field()); ?>


      </form>

    <?php else: ?>

      <form action="booking/payment" method="post">
        <div class="form-group date" data-provide="datepicker">
          <label for="name">Check In</label>
          <input class="form-control" type="text" name="start_date" value="<?php echo e($request->start_date); ?>">
          <?php if($errors->has('start_date')): ?>
            <p> <?php echo e($errors->first('start_date')); ?> </p>
          <?php endif; ?>
        </div>
        <div class="form-group date" data-provide="datepicker">
          <label for="name">Check Out</label>
          <input class="form-control" type="text" name="end_date" value="<?php echo e($request->end_date); ?>">
          <?php if($errors->has('start_date')): ?>
            <p> <?php echo e($errors->first('start_date')); ?> </p>
          <?php endif; ?>
        </div>
        <input type="hidden" name="room_id" value="<?php echo e($request->room_id); ?>">

        <input class="btn btn-default" type="submit" name="submit" value="Continue Payment">
        <?php echo e(csrf_field()); ?>


      </form>

    <?php endif; ?>

  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>